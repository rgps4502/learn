<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>google</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>54da8408-f1e4-478c-bed6-5a4108ee9ae9</testSuiteGuid>
   <testCaseLink>
      <guid>023db528-4bee-4f9b-b3b7-7cf7ba772a92</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/google/四方</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>6bf8746d-613e-4ec0-affb-c9409777a07d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/google/創google帳號</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    